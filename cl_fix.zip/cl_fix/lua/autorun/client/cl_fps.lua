/* -------------------------------------------------------------------------- */
/*                        pterohost.com Mods installer                        */
/* -------------------------------------------------------------------------- */

timer.Simple(1, function()
    RunConsoleCommand("cl_threaded_bone_setup", 1)
    RunConsoleCommand("cl_threaded_client_leaf_system", 1)
    RunConsoleCommand("r_threaded_client_shadow_manager", 1)
    RunConsoleCommand("r_threaded_particles", 1)
    RunConsoleCommand("r_threaded_renderables", 1)
    RunConsoleCommand("r_queued_ropes", 1)
    RunConsoleCommand("studio_queue_mode", 1)
    RunConsoleCommand("gmod_mcore_test", 1)
    RunConsoleCommand("mat_queue_mode", 2)


	-- RunConsoleCommand("r_3dsky", 0) -- Это дает большой буст фпс, но ломает много дополнений связанных с погодой
    RunConsoleCommand("in_usekeyboardsampletime", 0)
end)

hook.Add('InitPostEntity', "FixingFPSandOtherThings", function()
	LocalPlayer():ConCommand('cl_updaterate 20; cl_cmdrate 30; cl_interp 0.1; cl_interp_ratio 2;')
end)

MsgC('Pterohost.com - CL Fixer')