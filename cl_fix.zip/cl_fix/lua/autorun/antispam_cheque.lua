/* -------------------------------------------------------------------------- */
/*                        pterohost.com Mods installer                        */
/* -------------------------------------------------------------------------- */

if SERVER then

local ASC = {} -- Anti Spam Cheque
ASC.AntiSpam = function(ply,ply2,amount,entity)
	ply.numbercheque = 0
	for k ,v in pairs(ents.FindByClass("darkrp_cheque")) do
		if v:Getowning_ent() == ply then	
			ply.numbercheque = ply.numbercheque + 1
			if ply.numbercheque >= 2 then
				if IsValid(v) then
					v:Remove()
					ply:addMoney(amount)
				end
			end
		end	
	end
end
hook.Add("playerDroppedCheque","ASCAntiSpam", ASC.AntiSpam)
end