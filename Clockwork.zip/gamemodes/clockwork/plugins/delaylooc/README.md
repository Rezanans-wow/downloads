Delay LOOC
=================

Purpose
----

Will allow the administrative staff to set a delay between LOOC messages.

Config
----

Set the `looc_interval` config value either in the System menu or via command. The default value is set to 1 second.