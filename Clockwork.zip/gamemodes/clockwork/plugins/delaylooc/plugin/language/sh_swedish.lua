--[[
	© CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).

	Clockwork was created by Conna Wiles (also known as kurozael.)
	http://cloudsixteen.com/license/clockwork.html
--]]

CW_SWEDISH = Clockwork.lang:GetTable("Swedish");

CW_SWEDISH["WaitTalkInLOOC"] = "Du kan inte prata i LOOC förrän om #1 sekund(er)!";

CW_SWEDISH["LocalOOCInterval"] = "Lokal OOC Intervall";
CW_SWEDISH["LocalOOCIntervalDesc"] = "Tiden som en spelare måste vänta innan dom kan prata i LOOC igen (sekunder).\nVälj 0 för ingen intervall.";