﻿--[[
	© CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).

	Clockwork was created by Conna Wiles (also known as kurozael.)
	http://cloudsixteen.com/license/clockwork.html
--]]
--[[
   CONTRIBUTOR(s)
   ROSS  pootiswwe@gmail.com 
--]]

CW_RUSSIAN = Clockwork.lang:GetTable("Русский");

CW_RUSSIAN["MapSceneRemoved"] = "Вы успешно удалили #1 сцен.";
CW_RUSSIAN["MapSceneAdded"] = "Вы успешно добавили сцену.";
CW_RUSSIAN["MapSceneNoneNearPosition"] = "Вокруг вас нету сцен.";
CW_RUSSIAN["MapSceneNoneExist"] = "Тут нету сцен.";