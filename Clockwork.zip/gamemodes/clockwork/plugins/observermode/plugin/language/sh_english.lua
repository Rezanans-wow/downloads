--[[
	© CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).

	Clockwork was created by Conna Wiles (also known as kurozael.)
	http://cloudsixteen.com/license/clockwork.html
--]]

CW_ENGLISH = Clockwork.lang:GetTable("English");

CW_ENGLISH["ObserverReset"] = "Observer Reset";
CW_ENGLISH["ObserverResetDesc"] = "Whether or not observer mode resets the player's position to where they were originally.";