--[[
	© CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).

	Clockwork was created by Conna Wiles (also known as kurozael.)
	http://cloudsixteen.com/license/clockwork.html
--]]

CW_FRENCH = Clockwork.lang:GetTable("French");

CW_FRENCH["ObserverReset"] = "Observer Reset";
CW_FRENCH["ObserverResetDesc"] = "Que le mode observateur réinitialise la position du joueur d'origine.";