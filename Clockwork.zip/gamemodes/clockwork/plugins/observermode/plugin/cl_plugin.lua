local Clockwork = Clockwork;

Clockwork.config:AddToSystem("ObserverReset", "observer_reset", "ObserverResetDesc", true);
