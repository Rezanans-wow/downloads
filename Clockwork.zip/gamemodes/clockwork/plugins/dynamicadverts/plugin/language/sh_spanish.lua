--[[
	© 2015 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
	Clockwork was created by Conna Wiles (also known as kurozael.)
	http://cloudsixteen.com/license/clockwork.html
--]]

CW_SPANISH = Clockwork.lang:GetTable("Spanish");

CW_SPANISH["DynamicAdvertRemoved"] = "Has eliminado un total de #1 anuncio(s) dinámicos.";
CW_SPANISH["DynamicAdvertAdded"] = "Has creado un anuncio dinámico.";
CW_SPANISH["DynamicAdvertNoneNearPosition"] = "No hay ningún anuncio dinámico cerca de esta posición.";