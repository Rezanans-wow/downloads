--[[
	© CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).

	Clockwork was created by Conna Wiles (also known as kurozael.)
	http://cloudsixteen.com/license/clockwork.html
--]]

CW_ENGLISH = Clockwork.lang:GetTable("English");

CW_ENGLISH["TakePhyscannon"] = "Take Physcannon";
CW_ENGLISH["TakePhyscannonDesc"] = "Whether or not the player is stripped of the physics cannon.";