--[[
	© CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).

	Clockwork was created by Conna Wiles (also known as kurozael.)
	http://cloudsixteen.com/license/clockwork.html
--]]

CW_KOREAN = Clockwork.lang:GetTable("Korean");

CW_KOREAN["TakePhyscannon"] = "플레이어 중력건";
CW_KOREAN["TakePhyscannonDesc"] = "플레이어가 중력건에 의해 들어질 수 있는지에 대한 여부입니다.";