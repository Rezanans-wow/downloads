--[[
	© CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
	Clockwork was created by Conna Wiles (also known as kurozael.)
	http://cloudsixteen.com/license/clockwork.html
--]]

CW_KOREAN = Clockwork.lang:GetTable("Korean");

CW_KOREAN["DisplayTypingWhisper"] = "속삭이는 중...";
CW_KOREAN["DisplayTypingPerform"] = "행동하는 중...";
CW_KOREAN["DisplayTypingTalk"] = "말하는 중...";
CW_KOREAN["DisplayTypingRadio"] = "무전치는 중...";
CW_KOREAN["DisplayTypingYell"] = "외치는 중...";
CW_KOREAN["DisplayTypingType"] = "입력하는 중...";