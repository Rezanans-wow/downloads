--[[
	© CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).

	Clockwork was created by Conna Wiles (also known as kurozael.)
	http://cloudsixteen.com/license/clockwork.html
--]]

CW_KOREAN = Clockwork.lang:GetTable("Korean");

CW_KOREAN["SpawnWhereLeft"] = "위치 저장";
CW_KOREAN["SpawnWhereLeftDesc"] = "플레이어가 연결 해제된 지점에서 스폰되는지에 대한 여부입니다.";