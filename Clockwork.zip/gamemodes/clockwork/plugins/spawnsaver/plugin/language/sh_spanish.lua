--[[
	© 2015 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
	Clockwork was created by Conna Wiles (also known as kurozael.)
	http://cloudsixteen.com/license/clockwork.html
--]]

CW_SPANISH = Clockwork.lang:GetTable("Spanish");

CW_SPANISH["SpawnWhereLeft"] = "Spawn en desconexión";
CW_SPANISH["SpawnWhereLeftDesc"] = "Activa o desactiva la reaparición de jugadores en la posición de su desconexión";