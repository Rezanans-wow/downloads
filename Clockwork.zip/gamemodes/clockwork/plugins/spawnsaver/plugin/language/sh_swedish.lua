--[[
	© CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).

	Clockwork was created by Conna Wiles (also known as kurozael.)
	http://cloudsixteen.com/license/clockwork.html
--]]

CW_SWEDISH = Clockwork.lang:GetTable("Swedish");

CW_SWEDISH["SpawnWhereLeft"] = "Spawna Där Lämnat";
CW_SWEDISH["SpawnWhereLeftDesc"] = "Spawna där man lämnade förra gången.";