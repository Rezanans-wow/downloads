﻿--[[
	© CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).

	Clockwork was created by Conna Wiles (also known as kurozael.)
	http://cloudsixteen.com/license/clockwork.html
--]]

--[[
	Contributor(s):
		ROSS <pootiswwe@gmail.com>
--]]

CW_RUSSIAN = Clockwork.lang:GetTable("Русский");

CW_RUSSIAN["RemoveMapPhysics"] = "Убрать физику карты";
CW_RUSSIAN["RemoveMapPhysicsDesc"] = "Должны ли физические объекты карты быть удалены при запуске.";