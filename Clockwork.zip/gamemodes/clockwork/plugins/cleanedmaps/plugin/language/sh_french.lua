--[[
	© CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).

	Clockwork was created by Conna Wiles (also known as kurozael.)
	http://cloudsixteen.com/license/clockwork.html
--]]

CW_FRENCH = Clockwork.lang:GetTable("French");

CW_FRENCH["RemoveMapPhysics"] = "Supprimer la physique de la map";
CW_FRENCH["RemoveMapPhysicsDesc"] = "Que les entités physiques soient ou non supprimées lorsque la carte est chargée.";