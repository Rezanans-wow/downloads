--[[
	© CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).

	Clockwork was created by Conna Wiles (also known as kurozael.)
	http://cloudsixteen.com/license/clockwork.html
--]]

CW_KOREAN = Clockwork.lang:GetTable("Korean");

CW_KOREAN["RemoveMapPhysics"] = "맵 물리 프롭 제거";
CW_KOREAN["RemoveMapPhysicsDesc"] = "맵이 로드되었을 때 물리 엔티티를 제거할지에 대한 여부입니다.";