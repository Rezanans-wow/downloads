--[[
	© CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).

	Clockwork was created by Conna Wiles (also known as kurozael.)
	http://cloudsixteen.com/license/clockwork.html
--]]

CW_KOREAN = Clockwork.lang:GetTable("Korean");

CW_KOREAN["CrossServerChatEnabled"] = "서버 간 채팅 활성화";
CW_KOREAN["CrossServerChatEnabledDesc"] = "서버 간 채팅을 활성화 할지에 대한 여부입니다.";
CW_KOREAN["CrossServerChatName"] = "서버 간 채팅 이름";
CW_KOREAN["CrossServerChatNameDesc"] = "서버 간 채팅에 사용 될 서버의 이름입니다.";