--[[
	© 2015 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
	Clockwork was created by Conna Wiles (also known as kurozael.)
	http://cloudsixteen.com/license/clockwork.html
--]]

CW_SPANISH = Clockwork.lang:GetTable("Spanish");

CW_SPANISH["CrossServerChatEnabled"] = "Activar chat entre servidores";
CW_SPANISH["CrossServerChatEnabledDesc"] = "Activar o desactivar la posibilidad de conectar el chat entre diferentes servidores.";
CW_SPANISH["CrossServerChatName"] = "Nombre servidor chat entre servidores";
CW_SPANISH["CrossServerChatNameDesc"] = "Un nombre único utilizado para referirse al chat entre diferentes servidores.";