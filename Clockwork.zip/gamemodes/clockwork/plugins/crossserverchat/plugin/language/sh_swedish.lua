--[[
	© CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).

	Clockwork was created by Conna Wiles (also known as kurozael.)
	http://cloudsixteen.com/license/clockwork.html
--]]

CW_SWEDISH = Clockwork.lang:GetTable("Swedish");

CW_SWEDISH["CrossServerChatEnabled"] = "Kors Server Chatt Aktiverad";
CW_SWEDISH["CrossServerChatEnabledDesc"] = "Om chatt ska vara ansluten mellan flera servrar.";
CW_SWEDISH["CrossServerChatName"] = "Kors Server Chatt Namn";
CW_SWEDISH["CrossServerChatNameDesc"] = "Ett unikt namn för en kors server chatt.";