MsgC[[
    pterohost.com - Basic modules 
    What used/activated/installed?

    + Fix voicespam exploit
    + Fix stringcmd exploit
    + Automatic workshop resolved
    Credits to: msa.metastruct.net and Sammy for Automatic workshop resolver
]]

/* -------------------------------------------------------------------------- */
/*                                  Global {}                                 */
/* -------------------------------------------------------------------------- */
pterohost = 'pterohost.com'

